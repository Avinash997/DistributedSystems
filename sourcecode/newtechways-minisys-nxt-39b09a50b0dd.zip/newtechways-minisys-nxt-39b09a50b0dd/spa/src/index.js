import React from 'react';
import ReactDOM from 'react-dom';

import 'bootstrap/dist/css/bootstrap.min.css';
	
import App from './app/app.js'

ReactDOM.render(<App />, document.getElementById('root'));
