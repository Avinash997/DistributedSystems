export const PRODUCT_IMAGE_BASE_URL = "https://storage.googleapis.com/minisys/";

export const AUTH_SVC_URL = "http://localhost:8080/auth/"
export const PRODUCT_SVC_URL = "http://localhost:8080/products/";
export const CART_SVC_URL = "http://localhost:8080/carts/";
