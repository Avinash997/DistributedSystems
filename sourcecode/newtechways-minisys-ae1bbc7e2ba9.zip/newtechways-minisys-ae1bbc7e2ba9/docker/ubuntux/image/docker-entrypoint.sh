#!/bin/bash

vncserver -geometry 1600x900

tail -f /dev/null

